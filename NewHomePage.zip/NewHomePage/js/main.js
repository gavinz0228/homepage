function scrollToMoreInfo(){
    var height = $(window).height();

    $("html, body").animate({ scrollTop: height.toString()+"px" }, 500);
}